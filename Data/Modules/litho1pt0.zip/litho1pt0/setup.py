from distutils.core  import setup

# interface for Renka's algorithm 772 fortran code
# ext = Extension(name  = '_stripy',
#                 sources       = ['_stripy.pyf','_stripy.f90'])

if __name__ == "__main__":
    setup(name = 'litho1pt0',
          author            = "LM",
          author_email      = "louis.moresi@unimelb.edu.au",
          url               = "",
          download_url      = "",
          version           = "0.1",
          description       = "Python interface to STRIPACK fortran code for triangulation/interpolation on a sphere and a few more things",
          packages          = ['litho1pt0'],
          package_dir       = {'litho1pt0': 'litho1pt0'},
          package_data      = {'litho1pt0': ['data/*.npz'] }
          )
